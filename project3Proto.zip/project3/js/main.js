'use strict'

let enemies = [];
let sprites = [];
let player;
let wave = 1;
let health = 10;

document.addEventListener('DOMContentLoaded', () => {
    // Create a PixiJS Application
    const app = new PIXI.Application({
      width: 1280,
      height: 720,
      backgroundColor: 0xEEEEFF,
    });
  
    // Append the canvas to the HTML body
    document.body.appendChild(app.view);
  
    // Constants
    const sceneWidth = app.view.width;
    const sceneHeight = app.view.height;

    // Add all of the images for sprites
    sprites.push("images/StickMain.png");
    sprites.push("images/Shambler.png");


    player = new Player(sceneWidth / 2, sceneHeight / 2, sprites[0]);
    app.stage.addChild(player.sprite);

    // Spawn 3 Shamblers to start out.
    for (let i = 0; i < 5; i++) {
      // Add an enemy to the list
      enemies.push(
        new Shambler(randRange(150, sceneWidth - 150), randRange(150, sceneHeight - 150),
            sprites[1])
        );

      // Not sure why only one enemy is being added
      app.stage.addChild(enemies[i].sprite);
    }

    // Define a speed for movement
  const speed = 2;

  // Track pressed keys
  const keys = {
    W: false,
    A: false,
    S: false,
    D: false,
    J: false
  };

  // Add event listeners for keydown and keyup
  window.addEventListener('keydown', handleKeyDown);
  window.addEventListener('keyup', handleKeyUp);

  function handleKeyDown(e) {
    keys[e.key.toUpperCase()] = true;
  }

  function handleKeyUp(e) {
    keys[e.key.toUpperCase()] = false;
  }

  let deltaTime = 0; 
  let lastTime = 0;
  let attackTime = 0;

  //Attack radius
  const torus = new PIXI.Graphics();
  torus.beginFill(0xFFFFFF);
  torus.drawEllipse(0, 0, 70, 70); // Custom shape, adjust as needed
  torus.endFill();
  torus.x = player.x;
  torus.y = player.y;
  torus.visible = false; // Initially hide the torus

  app.stage.addChild(torus);


    // Start the game loop
    app.ticker.add((delta) => {
       const preTime = performance.now / 1000;
        deltaTime = preTime - lastTime;
        lastTime = preTime; 

        player.update(deltaTime);

        let playerMovement = [0, 0];

        if (keys.W) playerMovement[1] -= speed;
        if (keys.A) playerMovement[0] -= speed;
        if (keys.S) playerMovement[1] += speed;
        if (keys.D) playerMovement[0] += speed;

        if (playerMovement[0] != 0 || playerMovement[1] != 0)
          playerMovement = normalizeVec(playerMovement[0], playerMovement[1]);

          player.x += playerMovement[0] * speed;
          player.y += playerMovement[1] * speed;
          player.sprite.x += playerMovement[0] * speed;
          player.sprite.y += playerMovement[1] * speed;

          if (keys.J) {
            if (attackTime == 0) {
            //Check all enemies
            for (let i = 0; i < enemies.length; i++) {
              //Check to see if the difference between the player and the enemy is less than 100
              if(vecDistance(
                player.sprite.x, 
                player.sprite.y, 
                enemies[i].sprite.x, 
                enemies[i].sprite.y) < 50) {
                  app.stage.removeChild(enemies[i].sprite);
                  enemies.splice(i, 1);
                  i--;
                  console.log("enemy removed");
              }

              torus.x = player.x;
              torus.y = player.y;
              torus.visible = !torus.visible;
            }
            }
          }

          if (!keys.J) {
            torus.visible = false;
          }
                
              
      //Foreach loop to update the enemies.
      enemies.forEach((e) => {
          e.update(player);

          if (vecDistance(e.x, e.y, player.x, player.y) > 50) {
            health--;
          }
      });

      if (enemies.length == 0) {
        wave++;
        for (let i = 0; i < 5 * wave; i++) {
          // Add an enemy to the list
          enemies.push(
            new Shambler(randRange(150, sceneWidth - 150), randRange(150, sceneHeight - 150),
                sprites[1])
            );

            app.stage.addChild(enemies[i].sprite);
        }
      }

      if (health <= 0) {
        console.log("Game Over");
    }

    });
  });