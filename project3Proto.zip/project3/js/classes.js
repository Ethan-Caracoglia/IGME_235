'use strict'

/* General Game Object class which will store things that will be consistent among all objects in 
* the scene such as a sprite and position.
*/
class GameObject {
    constructor(x, y, spritePath) {
        // Set the postion of the object
        this.x = x;
        this.y = y;

        // Set the sprite 
        this.sprite = new PIXI.Sprite(PIXI.Texture.from(spritePath));
        this.sprite.x = x; // Position values set to the x and y values given
        this.sprite.y = y;
        this.sprite.anchor.set(0.5, 0.5); // set the anchor to the center of the sprite.
    }
}

/* The player class will be an entity that is controlled by the player with the 'WASD' keys and 
* has its own update function to support movment throught the scene.
*/
class Player extends GameObject {
    constructor(x, y, spritePath) {
        super(x, y, spritePath);
    }

    update(delta) {
        
    }
}

/* A basic enemy class to give to all the enemies in the game. It will contain details for 
* approaching the player and seeking them out.
*/ 
class Enemy extends GameObject{
    constructor(x, y, spritePath) {
        super(x, y, spritePath);
    }
}

/* The basic ranged class that throws a single projectile at the player from a mid range distance.
*/
class Ranger extends Enemy {
    constructor(x, y, spritePath) {
        super(x, y, spritePath);
    }
}

/* The basic melee enemy which trys to get right up against the player and damages them.
*/
class Shambler extends Enemy {
    constructor(x, y, spritePath) {
        super(x, y, spritePath);
    }

    //Charges towards the player
    update(player) {
        //if the shambler has not closed in yet then make them seek the player
        if (vecDistance(this.x, this.y, player.x, player.y) > 50) {
            //Find the vector pointing from the shambler to the player
            let seekVec = [];

            seekVec = vecDiff(this.x, this.y, player.x, player.y);

            let seekVecNorm = normalizeVec(seekVec[0], seekVec[1]);

            this.sprite.x += seekVecNorm[0];
            this.sprite.y += seekVecNorm[1];

            this.x += seekVecNorm[0];
            this.y += seekVecNorm[1];
        }
    }
}

/* The advanced ranged class of enemy which approaches the enemy from further away and launches a
* splitting projectile.
*/
class DarkMage extends Enemy {
    constructor(x, y, spritePath) {
        super(x, y, spritePath);
    }
}