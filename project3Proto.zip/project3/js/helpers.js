'use strict'

// Get a random number betwee th range of two numbers
function randRange(min, max) {
    return Math.random() * (max - min) + min;
}

// Get the distance between two points/vectors
function vecDistance(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
}

// Get the vector between two points
function vecDiff(x1, y1, x2, y2) {
    let x = x2 - x1;
    let y = y2 - y1;
    let vec = [x, y];
    return vec;
}

function getVecMagnitude(x, y) {
    let a2 = Math.pow(x, 2);
    let b2 = Math.pow(y, 2);
    return Math.sqrt(a2 + b2);
}

function normalizeVec(x, y) {
    let xNorm = x / getVecMagnitude(x, y);
    let yNorm = y / getVecMagnitude(x, y);
    return [xNorm, yNorm];
}