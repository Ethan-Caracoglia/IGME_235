'use strict'

// Get a random number betwee th range of two numbers
function randRange(min, max) {
    return Math.random() * (max - min) + min;
}